package org.cts.service;

import java.util.List;

import org.cts.bean.FlightInfo;
import org.cts.bean.ShowInvoice;


public interface ShowInvoiceService {
	
	public List<ShowInvoice> showInvoiceService();
}
