package org.cts.service;

import java.util.List;

import org.cts.bean.SearchFlight;

public interface ShowFlightService {

	public List showFlightService(SearchFlight obj);
}
