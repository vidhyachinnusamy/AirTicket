package org.cts.service;

import org.cts.bean.Booking;

public interface BookingService {
public boolean bookNow(Booking booking);
}
